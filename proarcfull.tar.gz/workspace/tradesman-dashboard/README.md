## SB Admin rewritten in Bootstrap 4

## Charts used:
####1. [Flot Charts](http://www.flotcharts.org/)

####2. [Morris Charts](http://morrisjs.github.io/morris.js/)


This project is a port of the famous Free Admin Bootstrap Theme [SB Admin](http://blackrockdigital.github.io/startbootstrap-sb-admin/).

Find out more [Themes at StrapUI.com](http://www.strapui.com/).

## Installation
####1. Clone this project or Download that ZIP file

```sh
$ git clone https://github.com/sahusoftcom/sb-admin-bs4.git
```

####2.  Plugins 

Make sure you have [font awesome] (https://fortawesome.github.io/Font-Awesome/)

