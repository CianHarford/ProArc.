<?php
    
    
   
    //Connect to the database
    $host = "127.0.0.1";
    $user = "x14500057";                     //Your Cloud 9 username
    $pass = "";                                  //Remember, there is NO password by default!
    $db = "ProArc";                                  //Your database name you want to connect to
    $port = 3306;                                //The port #. It is always 3306
    
    $connection = mysqli_connect($host, $user, $pass, $db, $port)or die(mysql_error());


        mysqli_select_db($connection,$db) or die(mysqli_error($connection));
        
        // username and password sent from form 
        $myusername=$_POST['user']; 
        $mypassword=$_POST['pass']; 
        
        // To protect MySQL injection (more detail about MySQL injection)
        $myusername = stripslashes($myusername);
        $mypassword = stripslashes($mypassword);
        
        $myusername = mysqli_real_escape_string($connection,$myusername);
        $mypassword = mysqli_real_escape_string($connection,$mypassword);
        
        $sql="SELECT * FROM UserT WHERE userName='$myusername' and password='$mypassword'";
        $result=mysqli_query($connection,$sql);
        
        // Mysql_num_row is counting table row
        $count=mysqli_num_rows($result);
        
        // If result matched $myusername and $mypassword, table row must be 1 row
        if($count==1){
        session_start();
        // Register $myusername, $mypassword and redirect to file "login_success.php"
        $_SESSION['myusername'];
        $_SESSION['mypassword']; 
        
        $_SESSION['myuser'] = $myusername;
        
        header("location:login_success.php");
        }
        else {
        echo "Wrong Username or Password";
        }
        

  ?>