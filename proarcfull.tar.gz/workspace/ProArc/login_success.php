<!--// Check if session is not registered, redirect back to main page. -->
<!--// Put this code in first line of web page. -->
<?php
session_start();
if(!$_SESSION['myusername']= "myusername"){
header("location:http://livedemo00.template-help.com/wt_58393/theme-5/site/ui_alerts.html#");
}else 
{
   
}
?>

<html>
<body>

<?php
session_start();
$myusername = $_SESSION['myuser'];
    
    
   
    //Connect to the database
    $host = "127.0.0.1";
    $user = "x14500057";                     //Your Cloud 9 username
    $pass = "";                                  //Remember, there is NO password by default!
    $db = "ProArc";                                  //Your database name you want to connect to
    $port = 3306;                                //The port #. It is always 3306
    
    $connection = mysqli_connect($host, $user, $pass, $db, $port)or die(mysql_error());



    //And now to perform a simple query to make sure it's working
    $query = "SELECT * FROM UserT Where userName = '$myusername'" ;
    $result = mysqli_query($connection, $query);
    //loop
    while ($row = mysqli_fetch_array($result,MYSQLI_ASSOC)) {
        //assign pulled data to variables
        $tempLoginID = $row['Login_ID'];
        $tempUsername = $row['userName'];
        $tempForename = $row['forename'];
        $tempSurname = $row['surname'];
        $tempEmail = $row['email'];
        $tempRole = $row['role'];
        
        //Displays pulled data
        echo "<b>Login ID:</b>".$tempLoginID.
        "<br><b>Username:</b>".$tempUsername.
        "<br><b>Forename:</b>".$tempForename.
        "<br><b>Surname: </b>".$tempSurname.
        "<br><b>E-mail: </b>".$tempEmail.
        "<br><b>Role: </b>".$tempRole.
        "<br><br><br>";
        
    }if($tempRole != 'Project Manager'){
            echo $myusername;}else{
        
    $query = "SELECT * FROM UserT Where  userName =  '$myusername'" ;
    $result = mysqli_query($connection, $query);
    //loop
    while ($row = mysqli_fetch_array($result,MYSQLI_ASSOC)) {
        //assign pulled data to variables
        
        
        $tempForename = $row['forename'];
        $tempSurname = $row['surname'];
        
        //Displays pulled data
        echo
        $tempForename." ".$tempSurname." Here are all tradesmen in your area listed below. <br><br>";
        
    
   
   
    }}if($tempRole != 'Project Manager'){
            echo " Welcome to your dashboard ";}else{
    
    $query = "SELECT * FROM UserT Where location = 'Dublin' AND userName !=  '$myusername' AND role != 'Project Manager'" ;
    $result = mysqli_query($connection, $query);
    //loop
    while ($row = mysqli_fetch_array($result,MYSQLI_ASSOC)) {
        //assign pulled data to variables
        
        
        $tempForename = $row['forename'];
        $tempSurname = $row['surname'];
        $tempRole = $row['role'];
        
        
            
        
        
        //Displays pulled data
        echo
        "<br><b>Forename:</b>".$tempForename.
        "<br><b>Surname: </b>".$tempSurname.
        "<br><b>Role: </b>".$tempRole.
        "<br><br>";
        }
    }
    
    
   // http://click4knowledge.com/php-login-script-tutorial.html
   
   //http://www.phpeasystep.com/phptu/6.html
    

  

?>



</body>
</html>