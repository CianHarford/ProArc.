<!doctype html>
<html>

<head>
    
</head>
<body>

   

<h2>Failed Payment</h2>

<form action="submit" value="Try Again">
    
    <h3>Invalid information or insufficient funds please try again. </h3>
    <input type="button" value="Try Again" src="http://proarcfull-x14500057-1.c9users.io/transaction.php"> <br> <input type="button" value="Return To Home" src="http://pro-arc-x14322731.c9users.io/transaction-page/home.php">
    
</form>

</div>

        
</html>
